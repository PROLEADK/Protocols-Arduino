ADC
===

Teensy 3.0 ADC implementation library created by Pedro Villanueva.

It implements all functions of the Teensy 3.0 internal ADC.

Some of the code was extracted from the file analog.c included in the distribution of Teensduino by PJRC.COM.

See example folder.

TODO:
  * Stuff related to the conversion speed and power. Useful if you want more speed or to save power.
