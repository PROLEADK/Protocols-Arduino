var annotated =
[
    [ "ADC", "class_a_d_c.html", "class_a_d_c" ],
    [ "RingBuffer", "class_ring_buffer.html", "class_ring_buffer" ]
];