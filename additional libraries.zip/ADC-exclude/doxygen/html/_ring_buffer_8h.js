var _ring_buffer_8h =
[
    [ "RingBuffer", "class_ring_buffer.html", "class_ring_buffer" ],
    [ "DEFAULT_BUFFER_SIZE", "_ring_buffer_8h.html#a6e576a3c6530636d68b7a220480bcd32", null ]
];