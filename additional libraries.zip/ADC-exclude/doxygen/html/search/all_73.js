var searchData=
[
  ['setaveraging',['setAveraging',['../class_a_d_c.html#aa80d9ebc6a60605e1b9a25f2db8734e9',1,'ADC']]],
  ['setreference',['setReference',['../class_a_d_c.html#a3871e90219238c6319c8b6bf801b5fd7',1,'ADC']]],
  ['setresolution',['setResolution',['../class_a_d_c.html#a79b5cb42cb1829a1de3f377664701c6e',1,'ADC']]],
  ['startanalogtimer',['startAnalogTimer',['../class_a_d_c.html#af093122742f6ac86684cb983d4293721',1,'ADC']]],
  ['startanalogtimerdifferential',['startAnalogTimerDifferential',['../class_a_d_c.html#adc1fe1cb2942e7aa12ea4737a529207c',1,'ADC']]],
  ['startcontinuous',['startContinuous',['../class_a_d_c.html#a332029f903b3d92cb52d2d8b1efe5ed6',1,'ADC']]],
  ['startcontinuousdifferential',['startContinuousDifferential',['../class_a_d_c.html#a013c9c109b7ccd038a5939866fe777ee',1,'ADC']]],
  ['startsingledifferential',['startSingleDifferential',['../class_a_d_c.html#a6780adeda5597efe5c09e6dfb5f49ae1',1,'ADC']]],
  ['startsingleread',['startSingleRead',['../class_a_d_c.html#a7759873f09a8369e41f12280234a383b',1,'ADC']]],
  ['stopanalogtimer',['stopAnalogTimer',['../class_a_d_c.html#abff12774fa2c93383e37c8bcf7ae5bfb',1,'ADC']]],
  ['stopcontinuous',['stopContinuous',['../class_a_d_c.html#a05857ba731f9b2b0ae35bef5c5cddd9e',1,'ADC']]]
];
