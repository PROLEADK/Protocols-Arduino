var searchData=
[
  ['disablecompare',['disableCompare',['../class_a_d_c.html#ad48e3b4b69170965fc4fe70ef042c099',1,'ADC']]],
  ['disabledma',['disableDMA',['../class_a_d_c.html#a58af22e8f95c1d2b1560153f906d1038',1,'ADC']]],
  ['disableinterrupts',['disableInterrupts',['../class_a_d_c.html#ad8acae7988973bdede138deea567623a',1,'ADC']]]
];
