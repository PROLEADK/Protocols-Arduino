var searchData=
[
  ['adc_5ferror_5fdiff_5fvalue',['ADC_ERROR_DIFF_VALUE',['../_a_d_c_8h.html#af181c4b5c617516517400c427494e7e7',1,'ADC.h']]],
  ['adc_5ferror_5fvalue',['ADC_ERROR_VALUE',['../_a_d_c_8h.html#a810b46bdaa73057d834142229111adc5',1,'ADC.h']]],
  ['analog_5ftimer_5ferror',['ANALOG_TIMER_ERROR',['../_a_d_c_8h.html#a12a745ce8b6499612828e575e39c46b0',1,'ADC.h']]]
];
