var searchData=
[
  ['getmaxvalue',['getMaxValue',['../class_a_d_c.html#a254cfc7c511bc29447d2a692433efe24',1,'ADC']]],
  ['getresolution',['getResolution',['../class_a_d_c.html#a3d365d0e397a9d2a5f23a117a4a7ef26',1,'ADC']]],
  ['gettimervalue',['getTimerValue',['../class_a_d_c.html#ac46fe3df35b3f92398f1d0d6bd2a72ac',1,'ADC']]]
];
