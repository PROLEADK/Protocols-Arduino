var searchData=
[
  ['default',['DEFAULT',['../_a_d_c_8h.html#a3da44afeba217135a680a7477b5e3ce3',1,'ADC.h']]],
  ['default_5fbuffer_5fsize',['DEFAULT_BUFFER_SIZE',['../_ring_buffer_8h.html#a6e576a3c6530636d68b7a220480bcd32',1,'RingBuffer.h']]]
];
