var class_a_d_c =
[
    [ "ADC", "class_a_d_c.html#a60b6e21403b1f30984f63832c0562960", null ],
    [ "~ADC", "class_a_d_c.html#aefd878291d0c14aa524df99af5a63148", null ],
    [ "disableCompare", "class_a_d_c.html#ad48e3b4b69170965fc4fe70ef042c099", null ],
    [ "disableDMA", "class_a_d_c.html#a58af22e8f95c1d2b1560153f906d1038", null ],
    [ "enableCompare", "class_a_d_c.html#a5bc29134a1079cc1c232a436c3778f88", null ],
    [ "enableCompareRange", "class_a_d_c.html#aee940d66774b13a343e85c358ee6cd45", null ],
    [ "enableDMA", "class_a_d_c.html#a10b9e674ed487b81160687e38fafbb59", null ],
    [ "getMaxValue", "class_a_d_c.html#a254cfc7c511bc29447d2a692433efe24", null ],
    [ "getTimerValue", "class_a_d_c.html#ac46fe3df35b3f92398f1d0d6bd2a72ac", null ],
    [ "isTimerLastValue", "class_a_d_c.html#ae834c6a54ed17ed9028d3203b1761da8", null ],
    [ "setAveraging", "class_a_d_c.html#aa80d9ebc6a60605e1b9a25f2db8734e9", null ],
    [ "setReference", "class_a_d_c.html#a3871e90219238c6319c8b6bf801b5fd7", null ],
    [ "startAnalogTimer", "class_a_d_c.html#af093122742f6ac86684cb983d4293721", null ],
    [ "startAnalogTimerDifferential", "class_a_d_c.html#adc1fe1cb2942e7aa12ea4737a529207c", null ],
    [ "startContinuous", "class_a_d_c.html#a332029f903b3d92cb52d2d8b1efe5ed6", null ],
    [ "startContinuousDifferential", "class_a_d_c.html#a013c9c109b7ccd038a5939866fe777ee", null ],
    [ "stopAnalogTimer", "class_a_d_c.html#abff12774fa2c93383e37c8bcf7ae5bfb", null ],
    [ "stopContinuous", "class_a_d_c.html#a05857ba731f9b2b0ae35bef5c5cddd9e", null ]
];