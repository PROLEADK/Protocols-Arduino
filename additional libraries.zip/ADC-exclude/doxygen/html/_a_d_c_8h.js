var _a_d_c_8h =
[
    [ "ADC", "class_a_d_c.html", "class_a_d_c" ],
    [ "ADC_ERROR_DIFF_VALUE", "_a_d_c_8h.html#af181c4b5c617516517400c427494e7e7", null ],
    [ "ADC_ERROR_VALUE", "_a_d_c_8h.html#a810b46bdaa73057d834142229111adc5", null ],
    [ "ANALOG_TIMER_ERROR", "_a_d_c_8h.html#a12a745ce8b6499612828e575e39c46b0", null ],
    [ "DEFAULT", "_a_d_c_8h.html#a3da44afeba217135a680a7477b5e3ce3", null ],
    [ "EXTERNAL", "_a_d_c_8h.html#af3fe37c1cda80aa7202b5a3bb7557dc9", null ],
    [ "INTERNAL", "_a_d_c_8h.html#a02c5e2eafaed44878fd8e6c54c8dde4d", null ],
    [ "INTERNAL1V1", "_a_d_c_8h.html#a56000ad2fa885e1acdbb06da63ded9bb", null ],
    [ "INTERNAL1V2", "_a_d_c_8h.html#ade90e2ab8528c36fd37e2c0ae653f704", null ],
    [ "MAX_ANALOG_TIMERS", "_a_d_c_8h.html#a7eb883900caaf62368bacfde26035535", null ]
];