var files =
[
    [ "ADC.cpp", "_a_d_c_8cpp.html", "_a_d_c_8cpp" ],
    [ "ADC.h", "_a_d_c_8h.html", "_a_d_c_8h" ],
    [ "RingBuffer.cpp", "_ring_buffer_8cpp.html", null ],
    [ "RingBuffer.h", "_ring_buffer_8h.html", "_ring_buffer_8h" ]
];