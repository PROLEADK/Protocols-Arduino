var searchData=
[
  ['write',['write',['../class_ring_buffer.html#aa14c47f5bbd73b5f8d2b83a86f01ccf2',1,'RingBuffer::write()'],['../class_ring_buffer_d_m_a.html#ac64de99b9ef9b4c1b1ae36444ce37699',1,'RingBufferDMA::write()']]]
];
