var searchData=
[
  ['savedcfg1',['savedCFG1',['../struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a1445124419626efa012c1afad2a2fac6',1,'ADC_Module::ADC_CONFIG']]],
  ['savedcfg2',['savedCFG2',['../struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a0189d428f05a6ead6e5d399b0908abd8',1,'ADC_Module::ADC_CONFIG']]],
  ['savedsc1a',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#accd8c37cf45a546feb90f21c37140652',1,'ADC_Module::ADC_CONFIG']]],
  ['savedsc2',['savedSC2',['../struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a3d0e4c301bf15ce0e11a56cd767a1012',1,'ADC_Module::ADC_CONFIG']]],
  ['savedsc3',['savedSC3',['../struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a26531cf1a408be6378e2bed2385da4b5',1,'ADC_Module::ADC_CONFIG']]],
  ['sc1a2channel',['sc1a2channel',['../class_a_d_c___module.html#a85269783274d11b1c7760fd929945380',1,'ADC_Module']]],
  ['sc1a2channeladc0',['sc1a2channelADC0',['../class_a_d_c.html#acc71c307c7465a59267edad4721bd7b0',1,'ADC']]],
  ['sc1a2channeladc1',['sc1a2channelADC1',['../class_a_d_c.html#aae8b20ab7f0bf1be34f5470fa53967b4',1,'ADC']]]
];
