var searchData=
[
  ['result_5fadc0',['result_adc0',['../struct_a_d_c_1_1_s_y_n_c___r_e_s_u_l_t.html#ab81e3b9f6f9b326cc29bb5dc9072fa3e',1,'ADC::SYNC_RESULT']]],
  ['result_5fadc1',['result_adc1',['../struct_a_d_c_1_1_s_y_n_c___r_e_s_u_l_t.html#aa96878f75289e66469ec37cb66a5c730',1,'ADC::SYNC_RESULT']]]
];
