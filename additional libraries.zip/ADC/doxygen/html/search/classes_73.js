var searchData=
[
  ['sync_5fresult',['SYNC_RESULT',['../struct_a_d_c_1_1_s_y_n_c___r_e_s_u_l_t.html',1,'ADC']]]
];
