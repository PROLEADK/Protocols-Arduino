var searchData=
[
  ['enablecompare',['enableCompare',['../class_a_d_c.html#a1987df39ccda1ce923eca878b3816383',1,'ADC::enableCompare()'],['../class_a_d_c___module.html#ae7a632267f21b79c31c1dae56b5da188',1,'ADC_Module::enableCompare()']]],
  ['enablecomparerange',['enableCompareRange',['../class_a_d_c.html#aa5b39a0ee459618f6b95cf4e48f77528',1,'ADC::enableCompareRange()'],['../class_a_d_c___module.html#ab8e64bab9d4e7f1935a260629e5d71d5',1,'ADC_Module::enableCompareRange()']]],
  ['enabledma',['enableDMA',['../class_a_d_c.html#a1bc9f7f1a0be0e38e9e6f517db8b2da7',1,'ADC::enableDMA()'],['../class_a_d_c___module.html#af3d14c01b1442c0c34b5dbc9a6e49f35',1,'ADC_Module::enableDMA()']]],
  ['enableinterrupts',['enableInterrupts',['../class_a_d_c.html#a55c8f57d2b3be4eb1216d45f652bc9c0',1,'ADC::enableInterrupts()'],['../class_a_d_c___module.html#a8be20cecbfb1e8900c9cd8d0bdb47ef7',1,'ADC_Module::enableInterrupts()']]],
  ['enablepga',['enablePGA',['../class_a_d_c.html#ace2f33764eff19fca2b1bea444a14819',1,'ADC::enablePGA()'],['../class_a_d_c___module.html#a5bef75f430c061b4bc3d48951e8930c6',1,'ADC_Module::enablePGA()']]]
];
