var searchData=
[
  ['vref_5fsc_5ficompen',['VREF_SC_ICOMPEN',['../_a_d_c___module_8h.html#a01f89b4b8b5e915d9840927eeec147d4',1,'ADC_Module.h']]],
  ['vref_5fsc_5fmode_5flv',['VREF_SC_MODE_LV',['../_a_d_c___module_8h.html#adda35e8438c7f36367f4ddd7ccd553c6',1,'ADC_Module.h']]],
  ['vref_5fsc_5fregen',['VREF_SC_REGEN',['../_a_d_c___module_8h.html#a28646efff164389096b14f99a643cf9a',1,'ADC_Module.h']]],
  ['vref_5fsc_5fvrefen',['VREF_SC_VREFEN',['../_a_d_c___module_8h.html#a20ed142ac118d12ce7ae750c5db95e06',1,'ADC_Module.h']]],
  ['vref_5fsc_5fvrefst',['VREF_SC_VREFST',['../_a_d_c___module_8h.html#aa097f88b5887410f535c56b419d2e8e0',1,'ADC_Module.h']]],
  ['vref_5ftrm_5fchopen',['VREF_TRM_CHOPEN',['../_a_d_c___module_8h.html#a0428c6e85511e76aee22a3f672e91b16',1,'ADC_Module.h']]]
];
