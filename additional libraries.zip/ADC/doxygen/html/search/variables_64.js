var searchData=
[
  ['dma_5fch0',['dma_Ch0',['../class_a_d_c.html#aaf4a9f1f20a59020a1d5849911f5547a',1,'ADC']]],
  ['dma_5fch1',['dma_Ch1',['../class_a_d_c.html#a11582ec89413ac8df558f8d0590508c2',1,'ADC']]],
  ['dma_5fchannel',['DMA_channel',['../class_ring_buffer_d_m_a.html#a58cb9dfc9b223725ac546c723beac5aa',1,'RingBufferDMA']]]
];
