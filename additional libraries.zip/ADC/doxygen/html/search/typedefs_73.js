var searchData=
[
  ['sync_5fresult',['Sync_result',['../class_a_d_c.html#a3d0e0013dca9f7a4d289722d71af24f7',1,'ADC']]]
];
