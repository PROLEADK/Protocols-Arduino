var searchData=
[
  ['disablecompare',['disableCompare',['../class_a_d_c.html#a3f511deae378e46a4a9ec80af90bf723',1,'ADC::disableCompare()'],['../class_a_d_c___module.html#ac635f675a9690a4db016c73c31818262',1,'ADC_Module::disableCompare()']]],
  ['disabledma',['disableDMA',['../class_a_d_c.html#ac53578061bc8bbbd1652b718c6032d07',1,'ADC::disableDMA()'],['../class_a_d_c___module.html#ac1610dcab46476f287c2dd4d96465c47',1,'ADC_Module::disableDMA()']]],
  ['disableinterrupts',['disableInterrupts',['../class_a_d_c.html#a269ea8bf6891c3095eea3b9d6decce67',1,'ADC::disableInterrupts()'],['../class_a_d_c___module.html#aa4509062644982526fee3c02e0b528fc',1,'ADC_Module::disableInterrupts()']]],
  ['disablepga',['disablePGA',['../class_a_d_c.html#ab9cb3e1c0ee39b45b4b84630606d85e1',1,'ADC::disablePGA()'],['../class_a_d_c___module.html#a734ac9cf07a54e91707c78d753d3d3dd',1,'ADC_Module::disablePGA()']]],
  ['dma_5fisr_5f0',['dma_isr_0',['../class_a_d_c.html#a73cb63fc02d6861aa3d2a393bf9d0485',1,'ADC::dma_isr_0()'],['../_a_d_c_8cpp.html#a66fa493056595dc39285952e112212e7',1,'dma_isr_0():&#160;ADC.cpp']]],
  ['dma_5fisr_5f1',['dma_isr_1',['../class_a_d_c.html#a576c55fc4ee3e0f32355c9cf46e08e53',1,'ADC::dma_isr_1()'],['../_a_d_c_8cpp.html#a153f4b5f45e012008581c1c34657e2e7',1,'dma_isr_1():&#160;ADC.cpp']]]
];
