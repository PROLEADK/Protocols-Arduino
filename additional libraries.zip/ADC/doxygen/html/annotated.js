var annotated =
[
    [ "ADC", "class_a_d_c.html", "class_a_d_c" ],
    [ "ADC_Module", "class_a_d_c___module.html", "class_a_d_c___module" ],
    [ "RingBuffer", "class_ring_buffer.html", "class_ring_buffer" ],
    [ "RingBufferDMA", "class_ring_buffer_d_m_a.html", "class_ring_buffer_d_m_a" ]
];