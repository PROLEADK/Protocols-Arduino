var class_ring_buffer_d_m_a =
[
    [ "RingBufferDMA", "class_ring_buffer_d_m_a.html#af3fd37c46b80508278bd9a05cefae859", null ],
    [ "~RingBufferDMA", "class_ring_buffer_d_m_a.html#ae7b0ff5b6789ac462a657602dbedc7c4", null ],
    [ "__attribute__", "class_ring_buffer_d_m_a.html#a334e3350b33de297d26dd776e8fad299", null ],
    [ "isEmpty", "class_ring_buffer_d_m_a.html#a0c10d34a151d2b9960e2ae58084e5baa", null ],
    [ "isFull", "class_ring_buffer_d_m_a.html#a52f974a38148e4baab0acbd2edb5c0e0", null ],
    [ "read", "class_ring_buffer_d_m_a.html#aad5fc1bf31314e717c4f47c3d62e7b31", null ],
    [ "start", "class_ring_buffer_d_m_a.html#ac04b74b351c1b37876ad0c954deab5a7", null ],
    [ "write", "class_ring_buffer_d_m_a.html#ac64de99b9ef9b4c1b1ae36444ce37699", null ],
    [ "DMA_channel", "class_ring_buffer_d_m_a.html#a58cb9dfc9b223725ac546c723beac5aa", null ]
];