var struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g =
[
    [ "savedCFG1", "struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a1445124419626efa012c1afad2a2fac6", null ],
    [ "savedCFG2", "struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a0189d428f05a6ead6e5d399b0908abd8", null ],
    [ "savedSC1A", "struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#accd8c37cf45a546feb90f21c37140652", null ],
    [ "savedSC2", "struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a3d0e4c301bf15ce0e11a56cd767a1012", null ],
    [ "savedSC3", "struct_a_d_c___module_1_1_a_d_c___c_o_n_f_i_g.html#a26531cf1a408be6378e2bed2385da4b5", null ]
];