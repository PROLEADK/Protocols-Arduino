ArduinoJsonParser change log
============================

v1.1 (unreleased)
----

* Example: changed `char* json` into `char json[]` so that the byes are not write protected
* Fixed parsing bug when the JSON contains multi-dimensional arrays

v1.0 
----

Initial release