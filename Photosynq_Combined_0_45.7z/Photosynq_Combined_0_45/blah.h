int MAG3110_init (void);
